
SinaProg 2.1 - AVRDUDE-GUI with AVR Fuse Calculator


* You can edit the file ".\data\Fuses.txt", to add your comments for writing fuse bits.

* If you have any problem with parallel port on Windows NT/2K/XP you must execute "install_giveio.bat" from ".\data\Giveio.zip".

* If you have any problem with USBasp programmer you must update the windows driver from ".\data\USBasp Driver 0.1.12.1.zip".

* For using SinaProg with Wine in Linux, rename "Port.txt" to "Port.win" and then rename "Port.lnx" to "Port.txt"


sn.ghaderi@yahoo.com


http://diy-elektronika.pl/424-programy-obslugujace-usbasp-pod-windows-7-xp